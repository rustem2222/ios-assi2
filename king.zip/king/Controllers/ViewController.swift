//
//  ViewController.swift
//  king
//
//  Created by Yersultan Mendigali on 27.01.2021.
//

import UIKit

class ViewController: UIViewController {
    
    var resArr = [Int]()


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func startGame() {
        let vc = storyboard?.instantiateViewController(identifier: "game") as! GameViewController
        vc.modalPresentationStyle = .fullScreen
        present(vc, animated: true)
    }
    @IBAction func history(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(identifier: "HistoryViewController") as! HistoryViewController
        vc.resultArrHistory.append(resArr[resArr.count-1])
        navigationController?.pushViewController(vc, animated: true)
    }
    
}

