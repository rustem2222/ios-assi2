//
//  ResultViewController.swift
//  king
//
//  Created by Yersultan Mendigali on 31.01.2021.
//

import UIKit

class ResultViewController: UIViewController {

    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var textLabel: UILabel!
    
    var resultArr = [Int]()
    var res: Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        guard let result = res else {
            return
        }
        resultArr.append(result)
        
        resultLabel.text = "\(result)0%"
        
        if result > 5 {
            textLabel.text = "Excellent"
        } else {
            textLabel.text = "Bad"
        }
        
    }

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
      let vc = GameViewController()
        self.present(vc, animated: true, completion: nil)
    }
    
    
    @IBAction func tryAgainFunc(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func homePageFunc(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(identifier: "ViewController") as! ViewController
        vc.resArr.append(resultArr[resultArr.count-1])
        navigationController?.pushViewController(vc, animated: true)
    }
}
